import { Component, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Dish } from '../Dish';
import { ReactiveFormsModule, Validators } from '@angular/forms';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-formul',
  templateUrl: './formul.component.html',
  styleUrls: ['./formul.component.css']
})

export class FormulComponent implements OnInit {
 
  @Output() dish = new EventEmitter<Dish>();

  collapseMenu: boolean = false;


  modelForm: FormGroup;
  constructor(private formBuilder : FormBuilder) {
    this.modelForm = this.formBuilder.group({
    nazwa: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
    kuchnia: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
    kategoria:  ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
    lista:  [[''], [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
    ilosc:  ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
    cena: ['', [Validators.required, Validators.pattern('^[0-9]+$')]], 
    opis:  ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
    img: ['', [Validators.required]],
    counter: 0
    
    });
  }
send(){
  let newDish : Dish = new Dish(
  this.modelForm.value.nazwa,
  this.modelForm.value.kuchnia,
  this.modelForm.value.kategoria,
  this.modelForm.value.lista,
  this.modelForm.value.ilosc,
  this.modelForm.value.cena,
  this.modelForm.value.opis,
  this.modelForm.value.img,
  )
  this.dish.emit(newDish);
  this.modelForm.reset();
}


get nazwa(){
  return this.modelForm.get('nazwa');
}

get kuchnia(){
  return this.modelForm.get('kuchnia');
}

get kategoria(){
  return this.modelForm.get('kategoria');
}

get lista(){
  return this.modelForm.get('lista');
}

get ilosc(){
  return this.modelForm.get('ilosc');
}

get cena(){
  return this.modelForm.get('cena');
}

get opis(){
  return this.modelForm.get('opis');
}

get img(){
  return this.modelForm.get('img');
}

ngOnInit() : void {
}


}
