import { Component, Input, OnInit } from '@angular/core';
import { listofdishes } from '../dishesList';
import { Dish } from '../Dish'
import { NumberValueAccessor } from '@angular/forms';

@Component({
  selector: 'app-dishes',
  templateUrl: './dishes.component.html',
  styleUrls: ['./dishes.component.css']
})
export class DishesComponent implements OnInit {

  dishes: Dish[] = []
  list: listofdishes = new listofdishes;
  ordersCounter = 0;
  maxcena = 0;
  mincena = Infinity;
  valuta = true;

  constructor() {

    this.list.getDishes().forEach(item => {
      this.dishes.push(item);
    });
    this.ramka();
    this.revolut();
  }

  put($event: Dish){

    this.dishes.push($event);
  }

  removePosition(object: Dish) {
    this.dishes.forEach((item, index) => {
      if (item === object) this.dishes.splice(index, 1);
    });
    this.ramka();
  }



  ramka() {
    this.maxcena = 0;
    this.mincena = Infinity;
    this.dishes.forEach((item => {
      if (item.cena > this.maxcena) {
        this.maxcena = item.cena;
      }
      if (item.cena < this.mincena) {
        this.mincena = item.cena;
      }
    }))
  }


  revolut() {
    if (this.valuta === true) { //dolar
      this.valuta = false; //euro
      this.dishes.forEach((item => {
        // var rounded = Math.round((numb + Number.EPSILON) * 100) / 100;
        item.cena = Math.round((item.cena * 0.8 + Number.EPSILON) * 100) / 100;
      }))
    }
    else {
      this.valuta = true;
      this.dishes.forEach((item => {
        item.cena = Math.round((item.cena * 1.25 + Number.EPSILON) * 100) / 100;
      }))
    }
    this.ramka()
  }


  plus(object: Dish) {
    if (object.ilosc > 0) {
      object.counter += 1;
      object.ilosc -= 1;
    }
    this.ordersCounter += 1;
  }


  minus(object: Dish) {
    if (object.counter > 0) {
      object.counter -= 1;
      object.ilosc += 1;
    }
    this.ordersCounter -= 1;
  }

  
  ngOnInit(): void {
  }

}
