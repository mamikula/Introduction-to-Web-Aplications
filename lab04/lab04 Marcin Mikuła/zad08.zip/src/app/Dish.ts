export class Dish{
    nazwa = '';
    kuchnia = '';
    kategoria = '';
    lista: string[] = [''];
    ilosc = 0;
    cena = 0;
    opis = "";
    img = "";
    counter = 0;

    constructor(nazwa: string, kuchnia: string, kategoria: string, lista: string[], ilosc: number, cena: number, opis: string, img: string ){
        this.nazwa = nazwa;
        this.kuchnia = kuchnia;
        this.kategoria = kategoria;
        this.lista = lista;
        this.ilosc = ilosc;
        this.cena = cena;
        this.opis = opis;
        this.img = img;
        this.counter = 0;
    }
}