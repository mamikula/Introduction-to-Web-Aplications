import { Injectable } from '@angular/core';
import { Dish } from './Dish';


@Injectable()
export class listofdishes {
  getDishes() {
    return [
      new Dish("Pierogi", "Polska", "Danie Główne", ["ziemniaki", " mąka"], 10, 11, "pierożki przepyszne", "https://aniastarmach.pl/content/uploads/2017/03/jak-zamrozic-pierogi-750x500.jpg"),


      new Dish("Spaghetti", "Włoska", "Danie Główne", ["makaron", " sos pomidorowy"], 12, 7, "makaronik ", "https://www.warzywizm.pl/wp-content/uploads/2021/07/A-WYBRANE-P1128074-auto-30-scaled-1.jpg"),


      new Dish("Kremówka", "Polska", "Deser", ["ciasto francuskie", "budyń"], 30, 5, "kremówka papieska", "https://www.mojegotowanie.pl/media/cache/default_view/uploads/media/recipe/0001/94/kremowki-tradycyjna-kremowka-papieska.jpeg"),

      new Dish("Naleśniki", "Polska", "Danie Główne", ["jajka", " mąka", "truskawki", "bita śmietana"], 50, 8, "super naleśniki", "https://ocdn.eu/pulscms-transforms/1/wD4k9kpTURBXy8zZGYzMmVkOGU0OTMxZDllMjVkZmY0OWI2ZDkwOTE0YS5qcGeTlQMAJ80E5s0CwZMFzQMUzQG8kwmmY2I4NmYzBoGhMAE/nalesniki-z-bita-smietana-i-owocami.jpg"),


      new Dish("Spaghetti", "Włoska", "Danie Główne", ["makaron", " sos pomidorowy"], 12, 7, "makaronik ", "https://www.warzywizm.pl/wp-content/uploads/2021/07/A-WYBRANE-P1128074-auto-30-scaled-1.jpg"),


      new Dish("Kremówka", "Polska", "Deser", ["ciasto francuskie", "budyń"], 30, 5, "kremówka papieska", "https://www.mojegotowanie.pl/media/cache/default_view/uploads/media/recipe/0001/94/kremowki-tradycyjna-kremowka-papieska.jpeg"),

      new Dish("Pierogi", "Polska", "Danie Główne", ["ziemniaki", " mąka"], 10, 11, "pierożki przepyszne", "https://aniastarmach.pl/content/uploads/2017/03/jak-zamrozic-pierogi-750x500.jpg"),


      new Dish("Spaghetti", "Włoska", "Danie Główne", ["makaron", " sos pomidorowy"], 12, 7, "makaronik ", "https://www.warzywizm.pl/wp-content/uploads/2021/07/A-WYBRANE-P1128074-auto-30-scaled-1.jpg"),


      new Dish("Kremówka", "Polska", "Deser", ["ciasto francuskie", "budyń"], 30, 5, "kremówka papieska", "https://www.mojegotowanie.pl/media/cache/default_view/uploads/media/recipe/0001/94/kremowki-tradycyjna-kremowka-papieska.jpeg"),

      new Dish("Pierogi", "Polska", "Danie Główne", ["ziemniaki", " mąka"], 10, 11, "pierożki przepyszne", "https://aniastarmach.pl/content/uploads/2017/03/jak-zamrozic-pierogi-750x500.jpg"),


      new Dish("Spaghetti", "Włoska", "Danie Główne", ["makaron", " sos pomidorowy"], 12, 7, "makaronik ", "https://www.warzywizm.pl/wp-content/uploads/2021/07/A-WYBRANE-P1128074-auto-30-scaled-1.jpg"),


      new Dish("Kremówka", "Polska", "Deser", ["ciasto francuskie", "budyń"], 30, 5, "kremówka papieska", "https://www.mojegotowanie.pl/media/cache/default_view/uploads/media/recipe/0001/94/kremowki-tradycyjna-kremowka-papieska.jpeg"),
  ]
  }
}


