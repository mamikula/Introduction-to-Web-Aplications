import { importExpr } from '@angular/compiler/src/output/output_ast';
import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  selectedBrand = 0;
  selectedModel = 0;
  selectedColor = 0;
  car = "";

  color = "";
  brand = "";
  model = "";

  models = this.getModels();
  colors = this.getColors();
  brands = this.getBrands();

  constructor() {
    this.models = [];
    this.colors = [];
  }

  onSelectBrand(brand_id: number) {
    this.selectedBrand = brand_id;
    this.selectedModel = 0;
    this.colors = [];
    this.models = this.getModels().filter((item) => {
      return item.brand_id === Number(brand_id)
    });
    this.car = "";
  }

  onSelectModel(model_id: number) {
    this.selectedModel = model_id;
    this.colors = this.getColors().filter((item) => {
      return item.model_id === Number(model_id)
    });
    this.car = "";
  }

  onSelectColor(color_id: number) {
    this.brand = this.getBrands().filter((item) => {
      return item.id === Number(this.selectedBrand);
    })[0].name
    this.model = this.getModels().filter((item) => {
      return item.id === Number(this.selectedModel);
    })[0].name
    this.color = this.getColors().filter((item) => {
      return item.id === Number(this.selectedColor);
    })[0].name

    this.car = this.brand + " " + this.model + " " + this.color;
  }





  getBrands() {
    return [
      { id: 1, name: 'Ford' },
      { id: 2, name: 'Audi' },
      { id: 3, name: 'Citroen' }
    ];
  }

  getModels() {
    return [
      { id: 1, brand_id: 1, name: 'Focus' },
      { id: 2, brand_id: 1, name: 'GT' },
      { id: 3, brand_id: 2, name: 'A1' },
      { id: 4, brand_id: 2, name: 'A6' },
      { id: 5, brand_id: 3, name: 'Berlingo' },
      { id: 6, brand_id: 3, name: 'C4' },
    ]
  }

  getColors() {
    return [
      { id: 1, model_id: 1, name: 'Red' },
      { id: 2, model_id: 1, name: 'White' },
      { id: 3, model_id: 1, name: 'Blue' },
      { id: 4, model_id: 1, name: 'Green' },
      { id: 5, model_id: 2, name: 'Purple' },
      { id: 6, model_id: 2, name: 'Grey' },
      { id: 7, model_id: 2, name: 'Orange' },
      { id: 8, model_id: 2, name: 'Yellow' },
      { id: 9, model_id: 3, name: 'Black' },
      { id: 10, model_id: 3, name: 'Cyan' },
      { id: 11, model_id: 3, name: 'Pink' },
      { id: 12, model_id: 4, name: 'Yellow' },
      { id: 13, model_id: 4, name: 'Black' },
      { id: 14, model_id: 5, name: 'Brown' },
      { id: 15, model_id: 5, name: 'Orange' },
      { id: 16, model_id: 5, name: 'Red' },
      { id: 17, model_id: 6, name: 'Green' },
      { id: 18, model_id: 6, name: 'Blue' },
    ]
  }
}