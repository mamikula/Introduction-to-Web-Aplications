import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})


export class ChildComponent implements OnInit {

  @Input() item = false;
  @Input() counter = 0;
  @Output() newClick = new EventEmitter<boolean>();
  @Output() newReset = new EventEmitter<boolean>();

  onClick(){
    if(this.item) this.newClick.emit(true);
  }
  onReset(){
    this.newReset.emit(true);
  }

  constructor() { }

  ngOnInit(): void {
  }
  
}
