import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  counter = 0;

  addOne(){
    this.counter += 1;
  }
  reset(){
    this.counter = 0;
  }

  blockClick(){
    if(this.counter >= 10) return false;
    else return true;
  }

  constructor() { }
  ngOnInit(): void {
  }

}



